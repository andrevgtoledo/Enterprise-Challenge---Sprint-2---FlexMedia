# Totem IA — Sprint 2  
**Continuação prática da arquitetura definida na Sprint 1 (Flexmedia Challenge)**

Este repositório contém a entrega completa da Sprint 2, com:
- Simulação de sensores
- Armazenamento SQL
- Análise estatística
- Dashboard em Streamlit
- Machine Learning supervisionado

Consulte o README original enviado no ChatGPT para mais detalhes.
